package com.example.tracker.domain.usecases

import com.example.tracker.domain.common.Transformer
import com.example.tracker.domain.entities.LoginEntity
import io.reactivex.Observable

class LoginUseCase(transformer: Transformer<LoginEntity>) : UseCase<LoginEntity>(transformer) {

    override fun createObservable(data: Map<String, Any>?): Observable<LoginEntity> {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

}