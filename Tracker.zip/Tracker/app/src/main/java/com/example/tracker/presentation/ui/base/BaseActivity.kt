package com.example.tracker.presentation.ui.base

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProviders
import com.example.tracker.injection.ViewModelFactory

abstract class BaseActivity<T : ViewModel> : AppCompatActivity() {

    abstract var viewModel: T

    abstract fun getViewModelType(): Class<T>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewModel = ViewModelProviders.of(this, ViewModelFactory(this)).get(getViewModelType())
    }
}