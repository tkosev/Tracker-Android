package com.example.tracker.presentation.ui.login

import com.example.tracker.base.BaseViewModel

class LoginViewModel : BaseViewModel() {


}