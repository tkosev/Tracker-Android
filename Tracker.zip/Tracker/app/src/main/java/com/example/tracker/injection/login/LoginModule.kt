package com.example.tracker.injection.login

import dagger.Module


@Module
class LoginModule {



}