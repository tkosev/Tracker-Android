package com.example.tracker.presentation.ui.custom.painter


data class Line(val startX: Float, var startY: Float, val endX: Float, var endY: Float) {

}