package com.example.tracker.domain.entities

data class LoginEntity(

    var isLoginSuccess :Boolean,
    var errorMessage : String
)

